const chalk = require("chalk");
const yargs = require("yargs");


console.log(process.argv);

// Customize yargs version
yargs.version('1.1.0')

// Utilisation de YARGS
// Create add command
yargs.command({
    command: 'add',
    describe: 'Add a new note',
    builder: {
        title: {
            describe: 'Note title',
            demandOption: true,
            type: 'string'
        },
        body: {
            describe: 'Note body',
            demandOption: true,
            type: 'string'
        }
    },
    handler(argv) {
        //TODO
    }
});

 
// Create list command
yargs.command({
    command: 'list',
    describe: 'List your notes',
    handler() {
        //TODO
    }
})

 

yargs.parse();