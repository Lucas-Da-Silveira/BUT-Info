SELECT * FROM laureates;

SELECT * FROM prize_laureates;

SELECT * FROM prizes;