class Equide{

    public int force;
    public int endurance;
    private int age;
    private int esperenceDeVie;
    private boolean isMale;

    public Equide(){
        if(this instanceof Bardot || this instanceof Etalon || this instanceof Ane || this instanceof Mulet){
            this.force = 6;
            this.endurance = 4;
            this.esperenceDeVie = 20;
        }else if(this instanceof Bardine || this instanceof Jument || this instanceof Anesse || this instanceof Mule){
            this.force = 4;
            this.endurance = 6;
            this.esperenceDeVie = 20;
        }
    }

}

class Bardots extends Equide{


}

class Chevaux extends Equide{

}

class Anes extends Equide{

}

class Mules extends Equide{

}

class Bardot extends Bardots{
    Bardot(){
        super();
        this.force--;
        this.endurance = 4;
    }

}

class Bardine extends Bardots{
    Bardine(){
        super();
        this.force--;
        this.endurance--;
    }

}

class Etalon extends Chevaux{
    Etalon(){
        super();
        this.force++;
        this.endurance--;
    }

}

class Jument extends Chevaux{
    Jument(){
        super();
        this.force--;
        this.endurance--;
    }

}

class Ane extends Anes{
    Ane(){
        super();
        this.endurance++;

    }

}

class Anesse extends Anes{
    Anesse(){
        super();
    }

}

class Mulet extends Mules{
    Mulet(){

    }

}

class Mule extends Mules{
    Mule(){

    }

}