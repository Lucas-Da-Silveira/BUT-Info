# Projet Dev Interface WEB

Membres du groupe 4 :
- Lucas DA SILVEIRA
- Tom SIOUAN
- Mathys NOURRY
- Ewan HUMBERT

Maquette: https://www.figma.com/file/YS88fIlPDDfvdcwiBBas1w/Ecommerce-Wireframe