class MaxTab{

    public static void main(String[]args){
        int[]tab = 
    }
}